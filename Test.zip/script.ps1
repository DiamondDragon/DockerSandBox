$packageFolder = '.\jetbrains.resharper.commandlinetools.2019.2.3'
$toolPath = "$packageFolder\tools\inspectcode.exe"
$configPath = ".\config.xml"

$solutionPath = '.\src\CodeAnalysisPoC.sln'

$artifactsFolder = '.\artifacts'
$inspectorReportPath = "$artifactsFolder\inspectcode.xml"
$inspectorOutputPath = "$artifactsFolder\inspectcode.output.txt"
$inspectorErrorPath = "$artifactsFolder\inspectcode.errors.txt"

Write-Host "Starting code inspections..."
Start-Process -FilePath $toolPath -RedirectStandardOutput $inspectorOutputPath -RedirectStandardError $inspectorErrorPath  -Wait -ArgumentList "-p=`"$configPath`" -o=`"$inspectorReportPath`" `"$solutionPath`"  "
Write-Host "Standard Output: "
Get-Content $inspectorOutputPath
Write-Host "Standard Error: "
Get-Content $inspectorErrorPath
